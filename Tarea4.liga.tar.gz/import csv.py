import csv
from collections import defaultdict

with open('season-1718.csv', 'r') as csvfile:
    lector_csv = csv.reader(csvfile)
    rows = list(lector_csv)
    if not rows:
        raise SystemExit("CSV vacío")

    header = rows[0]
    header_lc = [c.strip().lower() for c in header]
    has_header = any(
        any(k in c for k in ("home", "away", "local", "visitante", "team", "equipo", "fthg", "ftag", "goles"))
        for c in header_lc
    )

    start = 1 if has_header else 0

    col_map = {
        "home": None, "away": None,
        "home_goals": None, "away_goals": None,
        "home_yellow": None, "home_red": None, "away_yellow": None, "away_red": None
    }

    if has_header:
        for i, h in enumerate(header_lc):
            if any(k in h for k in ("home", "local", "localteam", "equipo_local")) and col_map["home"] is None:
                col_map["home"] = i
            if any(k in h for k in ("away", "visitante", "awayteam", "equipo_visitante")) and col_map["away"] is None:
                col_map["away"] = i
            if any(k in h for k in ("fthg", "hg", "home_goals", "goles_local", "goles_locales")) and col_map["home_goals"] is None:
                col_map["home_goals"] = i
            if any(k in h for k in ("ftag", "ag", "away_goals", "goles_visitante", "goles_visitantes")) and col_map["away_goals"] is None:
                col_map["away_goals"] = i
            if "yellow" in h and col_map["home_yellow"] is None and any(k in h for k in ("home", "local")):
                col_map["home_yellow"] = i
            if "yellow" in h and col_map["away_yellow"] is None and any(k in h for k in ("away", "visitante")):
                col_map["away_yellow"] = i
            if "red" in h and col_map["home_red"] is None and any(k in h for k in ("home", "local")):
                col_map["home_red"] = i
            if "red" in h and col_map["away_red"] is None and any(k in h for k in ("away", "visitante")):
                col_map["away_red"] = i


    def to_int(s):
        try:
            return int(float(s))
        except Exception:
            return 0

    if col_map["home"] is None or col_map["away"] is None or col_map["home_goals"] is None or col_map["away_goals"] is None:
        
        sample = rows[start]
        
        string_idxs = [i for i, v in enumerate(sample) if any(ch.isalpha() for ch in v)]
        num_idxs = [i for i, v in enumerate(sample) if any(ch.isdigit() for ch in v)]
        if len(string_idxs) >= 2:
            col_map["home"], col_map["away"] = string_idxs[0], string_idxs[1]
        if len(num_idxs) >= 2:
            col_map["home_goals"], col_map["away_goals"] = num_idxs[0], num_idxs[1]
        
        if len(num_idxs) >= 4:
            
            col_map["home_yellow"], col_map["home_red"], col_map["away_yellow"], col_map["away_red"] = (
                num_idxs[2], num_idxs[3], (num_idxs[4] if len(num_idxs) > 4 else None), (num_idxs[5] if len(num_idxs) > 5 else None)
            )

    teams = set()
    stats = defaultdict(lambda: {"points": 0, "gf": 0, "ga": 0, "yellow": 0, "red": 0})
    opponents = defaultdict(lambda: defaultdict(lambda: {"gf": 0, "ga": 0}))

    for r in rows[start:]:
        
        if len(r) <= max(i for i in col_map.values() if i is not None):
            continue
        home = r[col_map["home"]].strip()
        away = r[col_map["away"]].strip()
        hg = to_int(r[col_map["home_goals"]])
        ag = to_int(r[col_map["away_goals"]])
        hy = to_int(r[col_map["home_yellow"]]) if col_map["home_yellow"] is not None and col_map["home_yellow"] < len(r) else 0
        hr = to_int(r[col_map["home_red"]]) if col_map["home_red"] is not None and col_map["home_red"] < len(r) else 0
        ay = to_int(r[col_map["away_yellow"]]) if col_map["away_yellow"] is not None and col_map["away_yellow"] < len(r) else 0
        ar = to_int(r[col_map["away_red"]]) if col_map["away_red"] is not None and col_map["away_red"] < len(r) else 0

        teams.update([home, away])

        
        if hg > ag:
            hp, ap = 3, 0
        elif hg < ag:
            hp, ap = 0, 3
        else:
            hp, ap = 1, 1

        stats[home]["points"] += hp
        stats[away]["points"] += ap
        stats[home]["gf"] += hg
        stats[home]["ga"] += ag
        stats[away]["gf"] += ag
        stats[away]["ga"] += hg
        stats[home]["yellow"] += hy
        stats[home]["red"] += hr
        stats[away]["yellow"] += ay
        stats[away]["red"] += ar

        opponents[home][away]["gf"] += hg
        opponents[home][away]["ga"] += ag
        opponents[away][home]["gf"] += ag
        opponents[away][home]["ga"] += hg

    
    by_points = defaultdict(list)
    for t in teams:
        stats[t]["gd"] = stats[t]["gf"] - stats[t]["ga"]
        stats[t]["cards"] = stats[t]["yellow"] + stats[t]["red"]
        by_points[stats[t]["points"]].append(t)

    sorted_points = sorted(by_points.keys(), reverse=True)

    final_table = []
    rank = 1

    def sort_tie_group(group):
        
        h2h_vals = {}
        for t in group:
            hgf = sum(opponents[t][o]["gf"] for o in group if o in opponents[t])
            hga = sum(opponents[t][o]["ga"] for o in group if o in opponents[t])
            h2h_vals[t] = hgf - hga
        
        return sorted(group, key=lambda x: (-h2h_vals.get(x, 0), -stats[x]["gd"], -stats[x]["gf"], stats[x]["cards"], x))

    for pts in sorted_points:
        group = by_points[pts]
        if len(group) == 1:
            t = group[0]
            final_table.append((rank, t, stats[t]))
            rank += 1
        else:
            ordered = sort_tie_group(group)
            for t in ordered:
                final_table.append((rank, t, stats[t]))
                rank += 1

    
    print(f"{'Rk':>2} {'Equipo':30} {'Pts':>3} {'GF':>3} {'GA':>3} {'GD':>4} {'Tarj':>4}")
    for r, team, s in final_table:
        print(f"{r:>2} {team:30} {s['points']:>3} {s['gf']:>3} {s['ga']:>3} {s['gd']:>4} {s['cards']:>4}")